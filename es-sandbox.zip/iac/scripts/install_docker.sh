#!/bin/bash -e
(
	echo "INFO: looking for current docker installation!"

    # Install docker if --version fails
    if ! docker --version; then
        echo "ERROR: Docker not found, running docker install."

        echo "Update the apt package index and install packages to allow apt to use a repository over HTTPS:"
        
        until sudo apt-get update && sudo apt-get install \
            apt-transport-https \
            ca-certificates \
            curl \
            gnupg \
            lsb-release --assume-yes
        do
        echo "Try again"
        sleep 2
        done 
        
        echo "Add Docker’s official GPG key:"
        curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /usr/share/keyrings/docker-archive-keyring.gpg

        echo "Set up the stable repository."
        echo \
        "deb [arch=amd64 signed-by=/usr/share/keyrings/docker-archive-keyring.gpg] https://download.docker.com/linux/ubuntu \
        $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

        echo "Installing docker...."
        
        until sudo apt-get update --assume-yes && sudo apt-get install docker-ce docker-ce-cli containerd.io --assume-yes
        do
        echo "Try again"
        sleep 2
        done 
        
#        sudo systemctl status docker
        sudo chmod 666 /var/run/docker.sock
        exit        
    fi
	
)

# Verify that we can at least get version output
if ! docker --version; then
	echo "ERROR: Did Docker get installed?"
	exit 1
fi

# Attempt to run a container if not in a container
if [ ! -f /.dockerenv  ]; then
    sudo chmod 666 /var/run/docker.sock 
	if ! docker run --rm hello-world; then
		echo "ERROR: Could not get docker to run the hello world container"
		exit 2
	fi
fi

echo "INFO: Successfully verified docker installation!"