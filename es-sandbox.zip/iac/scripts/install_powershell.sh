#!/bin/bash -e
(
	echo "INFO: looking for current PowerShell installation!"

    # Install powershell if pswh -version fails
    if ! pwsh -version; then
        echo "ERROR: PowerShell not found, running PowerShell install."

        # Update the list of packages && Install pre-requisite packages.
        until sudo apt-get update && sudo apt-get install -y wget apt-transport-https software-properties-common
        do
        echo "Try again"
        sleep 2
        done 

        # Download the Microsoft repository GPG keys
        wget -q https://packages.microsoft.com/config/ubuntu/18.04/packages-microsoft-prod.deb
        # Register the Microsoft repository GPG keys
        until sudo dpkg -i packages-microsoft-prod.deb
        do
        echo "Try again"
        sleep 2
        done 

        # Update the list of products, Enable the "universe" repositories && Install PowerShell
        until sudo apt-get update && sudo add-apt-repository universe && sudo apt-get install -y powershell
        do
        echo "Try again"
        sleep 2
        done 
        
        echo "INFO:" pwsh -version
        exit
    fi
	
)

id

# Verify that we can at least get version output
if ! pwsh -version; then
	echo "ERROR: Did PowerShell get installed?"
	exit 1
    else
    echo "INFO: PowerShell is installed!"
fi

