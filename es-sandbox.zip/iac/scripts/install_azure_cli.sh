#!/bin/bash -e
(

    # Install Azure cli if az version fails
    echo "INFO: looking for current azure cli installation!"

    # Install Azure cli if --version fails
    if ! az --version; then
        echo "ERROR: Azure cli not found, running Azure cli install."

      
        until sudo apt-get update && sudo apt-get install ca-certificates curl apt-transport-https lsb-release gnupg
        do
        echo "Try again"
        sleep 2
        done 

#        until sudo apt-get update && sudo apt-get install -y libssl-dev libffi-dev && sudo apt-get install -y python-dev
#        do
#        echo "Try again"
#        sleep 2
#        done 

#        curl -L https://aka.ms/InstallAzureCli | bash
        
        curl -sL https://packages.microsoft.com/keys/microsoft.asc |
            gpg --dearmor |
            sudo tee /etc/apt/trusted.gpg.d/microsoft.gpg > /dev/null
        AZ_REPO=$(lsb_release -cs)
        echo "deb [arch=amd64] https://packages.microsoft.com/repos/azure-cli/ $AZ_REPO main" |
            sudo tee /etc/apt/sources.list.d/azure-cli.list
        
        until sudo apt-get update && sudo apt-get install azure-cli
        do
        echo "Try again"
        sleep 2
        done 
        exit
    fi
	
)

# Verify that we can at least get version output
if ! az --version; then
	echo "ERROR: Did Azure cli get installed?"
	exit 1
fi
echo "INFO: Successfully installed Azure cli!"