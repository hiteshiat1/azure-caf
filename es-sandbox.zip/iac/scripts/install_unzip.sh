#!/bin/bash -e
(

    # Install Azure cli if az version fails
    echo "INFO: looking for current unzip installation!"

    # Install Azure cli if --version fails
    if ! unzip -v; then
        echo "ERROR: unzip not found, running unzip cli install."
        until sudo apt-get update && sudo apt-get install unzip
        do
        echo "Try again"
        sleep 2
        done
        exit 
    fi
	
)

echo "INFO: Successfully installed unzip!"