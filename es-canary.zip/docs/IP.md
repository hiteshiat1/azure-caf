![L&G](/docs/images/LandG_logo_128.png)
# Platform IP Addresses - DRAFT
> Here's a list of ip addresses used as part of enterprise scale. this is not a list of all IP addresses used in Azure. Furthermore this file should be replaced by a IPAM solution asap.

<hr>

## 1. IP Address List Table
![Git](/docs/images/excel_s.png)

[Open document](/docs/IP%20Address%20List.xlsx)

## 2. IP Address Allocation

| Starting IP Address   | CIDR | Total Number of Hosts  | Region    |
| :---                  |    :----:   |    :----:       |    :----: |
| 10.160.0.0             | /16        | 65,534          | UK South  |
| 10.161.0.0             | /16        | 65,534          | UK South  |
| 10.170.0.0             | /16        | 65,534          | UK West   |
| 10.171.0.0             | /16        | 65,534          | UK West   |
<hr>